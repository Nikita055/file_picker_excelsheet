package com.rajkamal.assettrack;

import android.Manifest;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import com.thanosfisherman.mayi.Mayi;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        Mayi.withActivity(LoginActivity.this)
                .withPermissions(Manifest.permission.WRITE_EXTERNAL_STORAGE,Manifest.permission.READ_EXTERNAL_STORAGE
                        ,Manifest.permission.CAMERA,Manifest.permission.INTERNET)
                .check();
    }

    public void loginClick(View view) {



        startActivity(new Intent(LoginActivity.this,MenuActivity.class));
        finish();

    }
    }

